-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: book_shop
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `author_id` bigint NOT NULL AUTO_INCREMENT,
  `author_name` varchar(255) NOT NULL,
  `img_url` longtext,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'Masami Sasaki',NULL),(2,'Wakamatsu Aki',NULL),(3,'Masato Takeuchi',NULL),(4,'Adrian Kulp',NULL),(5,'Antoine de Saint-Exupéry',NULL),(6,'Phùng Quán',NULL),(7,'Jun Phạm',NULL),(8,'Tô Hoài',NULL),(9,'Luis Sepúlveda',NULL),(10,'Hà Yên',NULL),(11,'Yosbook',NULL),(12,'Xiao Li',NULL),(13,'Nhiều Tác Giả',NULL),(14,'Neung In Publishing Company',NULL),(15,'Daniel Howarth',NULL),(16,'Tạ Huy Long',NULL),(17,'Nguyễn Thị Xuân Phượng',NULL),(18,'Paul Kalanithi',NULL),(19,'Nguyễn Chí Vịnh',NULL),(20,'Matt Haig',NULL),(21,'Trịnh Công Sơn',NULL),(22,'Nikola Tesla',NULL),(23,'Tuệ Minh',NULL),(24,'ONO Eriko',NULL),(25,'Soubee Amako',NULL),(26,'Gege Akutami',NULL),(27,'Ichimon Izumi',NULL),(28,'Sorata Akiduki',NULL),(29,'Kagiji KUMANOMATA',NULL),(30,'Thanh Y',NULL),(31,'Franz Kafka',NULL),(32,'Nguyễn Trung Kiên',NULL),(33,'Cam (Write To Death)',NULL),(34,'52.0 Hz',NULL),(35,'Patrick Modiano',NULL),(36,'Neil Gaiman',NULL),(37,'Mario Puzo',NULL),(38,'Hồ Chí Minh',NULL),(39,'hdfhf',NULL),(40,'tuantaitu',NULL),(41,'tunangoo',NULL),(45,'ngovngnantuan',NULL),(46,'ngovngnnfgnfgantuan',NULL),(47,'ngovnggngfnfnnfgnfgantuan',NULL),(49,'ttt',NULL);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 11:27:17
